// import { employee } from "./employee.model";

export interface department {
    id : number,
    name : string
}