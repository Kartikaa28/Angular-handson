import { employee } from "./employee";

let emp : employee = {id:1, name:"John", salary:5000, permanent:true, dept:{id:8,name:"Gaming"}, 
                    skill : [
        { id: 1, name: "HTML" },
        { id: 2, name: "CSS" },
        { id: 3, name: "JavaScript" }
    ]};

console.log(emp);


