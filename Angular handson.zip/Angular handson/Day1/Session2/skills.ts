
export interface skill {
    skill : string
}[];