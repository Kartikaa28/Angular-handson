"use strict";
exports.__esModule = true;
var emp = { id: 1, name: "John", salary: 5000, permanent: true,
    dept: { id: 8, name: "Gaming" },
    skill: ["HTML", "CSS", "JavaScript"] };
console.log(emp);
